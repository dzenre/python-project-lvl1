"""Brain even game."""
from random import randint

import prompt

from brain_games.cli import welcome_user


def is_even(num):
    if num % 2 == 0:
        answer = 'yes'
        return True, answer
    answer = 'no'
    return False, answer


def check_even():
    player = welcome_user()
    print('Answer "yes" if the number is even, otherwise answer "no".')
    wins_count = 0
    while wins_count < 3:
        randnum = randint(1, 1000)
        guess = prompt.string('Question: {}\n'.format(randnum))
        answer = is_even(randnum)[1]
        if is_even(randnum) and guess == answer:
            print('Correct!')
            wins_count += 1
        elif not is_even(randnum) and guess == answer:
            print('Correct!')
            wins_count += 1
        else:
            print(
                '"{}" is a wrong answer! Correct answer was "{}"'.
                format(guess, answer),
                )
            print("Let's try again, {}!".format(player))
            wins_count = 0
    print('Congratulations, {}!'.format(player))
